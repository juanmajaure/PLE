import sys
sys.path.append(r"C:\Program Files\IBM\ILOG\CPLEX_Studio2211\cplex\python\3.10\x64_win64")
#importamos el modulo cplex
import cplex

TOLERANCE =10e-6 

class InstanciaRecorridoMixto:
    def __init__(self):
        self.cantidad_clientes = 0
        self.costo_repartidor = 0
        self.d_max = 0
        self.refrigerados = []
        self.exclusivos = []
        self.distancias = []        
        self.costos = []        

    def leer_datos(self,filename):
        # abrimos el archivo de datos
        f = open(filename)

        # leemos la cantidad de clientes
        self.cantidad_clientes = int(f.readline())
        # leemos el costo por pedido del repartidor
        self.costo_repartidor = int(f.readline())
        # leemos la distamcia maxima del repartidor
        self.d_max = int(f.readline())
        
        # inicializamos distancias y costos con un valor muy grande (por si falta algun par en los datos)
        self.distancias = [[1000000 for _ in range(self.cantidad_clientes)] for _ in range(self.cantidad_clientes)]
        self.costos = [[1000000 for _ in range(self.cantidad_clientes)] for _ in range(self.cantidad_clientes)]
        
        # leemos la cantidad de refrigerados
        cantidad_refrigerados = int(f.readline())
        # leemos los clientes refrigerados
        for i in range(cantidad_refrigerados):
            self.refrigerados.append(int(f.readline()))
        
        # leemos la cantidad de exclusivos
        cantidad_exclusivos = int(f.readline())
        # leemos los clientes exclusivos
        for i in range(cantidad_exclusivos):
            self.exclusivos.append(int(f.readline()))
        
        # leemos las distancias y costos entre clientes
        lineas = f.readlines()
        for linea in lineas:
            row = list(map(int,linea.split(' ')))
            self.distancias[row[0]-1][row[1]-1] = row[2]
            self.distancias[row[1]-1][row[0]-1] = row[2]
            self.costos[row[0]-1][row[1]-1] = row[3]
            self.costos[row[1]-1][row[0]-1] = row[3]
        
        # cerramos el archivo
        
        f.close()

def cargar_instancia():
    # El 1er parametro es el nombre del archivo de entrada
    nombre_archivo = sys.argv[1].strip()
    # Crea la instancia vacia
    instancia = InstanciaRecorridoMixto()
    # Llena la instancia con los datos del archivo de entrada 
    instancia.leer_datos(nombre_archivo)
    return instancia

def agregar_variables(prob, instancia):
    # Definir y agregar las variables:
	# metodo 'add' de 'variables', con parametros:
	# obj: costos de la funcion objetivo
	# lb: cotas inferiores
    # ub: cotas superiores
    # types: tipo de las variables
    # names: nombre (como van a aparecer en el archivo .lp)
	
    # Poner nombre a las variables y llenar coef_funcion_objetivo
    #Cantidad de clientes
    n= instancia.cantidad_clientes
    nombres =[]
    coeficientes_funcion_objetivo=[]
    cotas_inferiores=[]
    cotas_superiores=[]
    tipos=[]
    #Primero agrego las de si el camion va o no por un arco x_ij
    for i in range(1,n+1):
        for j in range(1,n+1):
            if(i!=j):
                coeficientes_funcion_objetivo.append(instancia.costos[i-1][j-1])
                nombres.append(f"x_{i}_{j}")
                cotas_inferiores.append(0)
                cotas_superiores.append(1)
                tipos.append('B')

    #Primero agrego las de si un repartidor va o no por un arco y_ij
    for i in range(1,n+1):
        for j in range(1,n+1):
            if(i!=j):
                coeficientes_funcion_objetivo.append(instancia.costo_repartidor)
                nombres.append(f"y_{i}_{j}")
                cotas_inferiores.append(0)
                cotas_superiores.append(1)
                tipos.append('B')
    
    #u_1 es 0
    coeficientes_funcion_objetivo.append(0)
    nombres.append("u_1")
    cotas_inferiores.append(0)
    cotas_superiores.append(0) #esto me fija su valor en 0
    tipos.append('I')

    #ahora agrego las de posicion u_i

    for i in range(2,n+1):
        coeficientes_funcion_objetivo.append(0)
        nombres.append(f"u_{i}")
        cotas_inferiores.append(-1)
        cotas_superiores.append(n-1)
        tipos.append('I')
    
    #p_1 es 0
    coeficientes_funcion_objetivo.append(0)
    nombres.append("p_1")
    cotas_inferiores.append(1)
    cotas_superiores.append(1) #esto me fija su valor en 0
    tipos.append('B')


    #p_i es o no parada del camion
    for i in range(2,n+1):
        coeficientes_funcion_objetivo.append(0)
        nombres.append(f"p_{i}")
        cotas_inferiores.append(0)
        cotas_superiores.append(1)
        tipos.append('B')

    #Agregamos c cantidad de paradas del camion
    coeficientes_funcion_objetivo.append(0)
    nombres.append(f"c")
    cotas_inferiores.append(0)
    cotas_superiores.append(n)
    tipos.append('I')


    #argegamos variables de si salen o no repartidores de i
    for i in range(1,n+1):
        coeficientes_funcion_objetivo.append(0)
        nombres.append(f"d_{i}")
        cotas_inferiores.append(0)
        cotas_superiores.append(1)
        tipos.append('B')

    # Agregar las variables
    prob.variables.add(obj = coeficientes_funcion_objetivo, lb = cotas_inferiores, ub = cotas_superiores, types=tipos, names=nombres)

def agregar_restricciones(prob, instancia):
    # Agregar las restricciones ax <= (>= ==) b:
	# funcion 'add' de 'linear_constraints' con parametros:
	# lin_expr: lista de listas de [ind,val] de a
    # sense: lista de 'L', 'G' o 'E'
    # rhs: lista de los b
    # names: nombre (como van a aparecer en el archivo .lp)

    # Notar que cplex espera "una matriz de restricciones", es decir, una
    # lista de restricciones del tipo ax <= b, [ax <= b]. Por lo tanto, aun cuando
    # agreguemos una unica restriccion, tenemos que hacerlo como una lista de un unico
    # elemento.
    n=instancia.cantidad_clientes
    R= [1 if i+1 in instancia.refrigerados else 0 for i in range(n)]
    Exclusivos= [1 if i+1 in instancia.exclusivos else 0 for i in range(n)]

    #entro a todo cliente
    for i in range(1,n+1):
        variables_entrantes = [f"x_{j}_{i}" for j in range(1,n+1) if i!=j] + [f"y_{j}_{i}" for j in range(1,n+1) if i!=j]
        valores=[1.0] * (n-1)*2
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["E"], rhs=[1], names=[f"llego_a_{i}_de_alguna_manera"])
    
    #es o no parada del camion
    for i in range(1,n+1):
        variables_entrantes = [f"x_{j}_{i}" for j in range(1,n+1) if i!=j] + [f"p_{i}"]
        valores=[1.0] * (n-1) + [-1.0]
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["E"], rhs=[0], names=[f"cliente_{i}_es_parada"])
    
    #si llego con camion salgo con camion
    for i in range(1,n+1):
        variables_entrantes = [f"x_{j}_{i}" for j in range(1,n+1) if i!=j] + [f"x_{i}_{j}" for j in range(1,n+1) if i!=j]
        valores=[1.0] * (n-1) + [-1.0] *(n-1)
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["E"], rhs=[0], names=[f"si_camion_llego_{i}_salio"])
    
    #si sale repartidor de i, llegue a i con camion
    for i in range(1,n+1):
        variables_entrantes = [f"y_{i}_{j}" for j in range(1,n+1) if i!=j] + [f"p_{i}"]
        valores=[1.0] * (n-1) + [-n]
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["L"], rhs=[0], names=[f"repartidores_desde_{i}"])
    
    #si llego con repartidor esta a d_max
    for i in range(1,n+1):
        for j in range(1,n+1):
            if(j!=i):
                variables=[f"y_{i}_{j}"]
                valores=[instancia.distancias[i-1][j-1]]
                fila=[variables,valores]
                prob.linear_constraints.add(lin_expr=[fila], senses=["L"], rhs=[instancia.d_max], names=[f"distancia_repartidor_{i}_{j}"])
    
    #solo un refrigerado por repartidor
    for i in range(1,n+1):
        variables_entrantes = [f"y_{i}_{j}" for j in range(1,n+1) if i!=j]
        valores=R[:(i-1)] + R[i:]
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["L"], rhs=[1], names=[f"refrigerados_desde_{i}"])

    #cantidad paradas del camion
    
    variables_entrantes = [f"p_{i}" for i in range(1,n+1)] + ["c"]
    valores=[1.0] * (n) + [-1]
    fila = [variables_entrantes,valores]
    prob.linear_constraints.add(lin_expr=[fila], senses=["E"], rhs=[0], names=[f"cantidad_paradas"])

    #continuidad
    for i in range(1,n+1):
        for j in range(2,n+1):
            if(j!=i):
                variables=[f"u_{i}",f"u_{j}",f"x_{i}_{j}"]
                valores=[1.0,-1.0,n+1]
                fila=[variables,valores]
                prob.linear_constraints.add(lin_expr=[fila], senses=["L"], rhs=[n], names=[f"continuidad_{i}_{j}"])
    
    #posiciones son como maximo cantidad de paradas
    for i in range(1,n+1):
        variables_entrantes = [f"u_{i}", "c"]
        valores=[1.0,-1.0]
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["L"], rhs=[-1], names=[f"posicion_{i}_no_supera_cant_paradas"])
    

    #salen o no repartidores desde cliente i
    for i in range(1,n+1):
        variables_entrantes = [f"y_{i}_{j}" for j in range(1,n+1) if i!=j] + [f"d_{i}"]
        valores=[1.0] * (n-1) + [-n]
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["L"], rhs=[0], names=[f"salen_repartidores_desde_{i}"])
    
    #si salen, salen 4, sino no sale ninguno
    for i in range(1,n+1):
        variables_entrantes = [f"y_{i}_{j}" for j in range(1,n+1) if i!=j] + [f"d_{i}"]
        valores=[1.0] * (n-1) + [-4]
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["G"], rhs=[0], names=[f"salen_4_mas_repartidores_o_0_de_{i}"])
    
    #visito con camion mis clientes exclusivos
    for i in range(1,n+1):
        if(Exclusivos[i-1]==1):
            variables_entrantes = [f"p_{i}"]
            valores=[1.0]
            fila = [variables_entrantes,valores]
            prob.linear_constraints.add(lin_expr=[fila], senses=["E"], rhs=[1], names=[f"cliente_{i}_exclusivo"])
    
def armar_lp(prob, instancia):

    # Agregar las variables
    agregar_variables(prob, instancia)
   
    # Agregar las restricciones 
    agregar_restricciones(prob, instancia)

    # Setear el sentido del problema
    prob.objective.set_sense(prob.objective.sense.minimize)

    # Escribir el lp a archivo
    prob.write('recorridoMixto.lp')

def resolver_lp(prob):
    
    prob.solve()

def mostrar_solucion(prob,instancia):
    
    # Obtener informacion de la solucion a traves de 'solution'
    
    # Tomar el estado de la resolucion
    status = prob.solution.get_status_string(status_code = prob.solution.get_status())
    
    # Tomar el valor del funcional
    valor_obj = prob.solution.get_objective_value()
    
    print('Funcion objetivo: ',valor_obj,'(' + str(status) + ')')
    
    # Tomar los valores de las variables
    x  = prob.solution.get_values()
    nombres_variables  = prob.variables.get_names()#AGREGADO
    # Mostrar las variables con valor positivo (mayor que una tolerancia)
    for i in range(len(x)):#AGREGADO
        if x[i] > TOLERANCE:
            print(nombres_variables[i] + ':' , x[i])
    

def main():
    
    # Lectura de datos desde el archivo de entrada
    instancia = cargar_instancia()
    
    # Definicion del problema de Cplex
    prob = cplex.Cplex()
    
    # Definicion del modelo
    armar_lp(prob,instancia)

    prob.parameters.timelimit.set(500)  # límite de tiempo en segundos

    # Preprocesamiento mínimo
    # prob.parameters.preprocessing.presolve.set(1)
    # prob.parameters.preprocessing.reduce.set(1)
    # prob.parameters.preprocessing.aggregator.set(0)
    # prob.parameters.preprocessing.linear.set(0)
    # prob.parameters.preprocessing.boundstrength.set(0)

    # Resolucion del modelo
    resolver_lp(prob)

    # Obtencion de la solucion
    mostrar_solucion(prob,instancia)

if __name__ == '__main__':
    main()