import sys
sys.path.append(r"C:\Program Files\IBM\ILOG\CPLEX_Studio2211\cplex\python\3.10\x64_win64")
#importamos el modulo cplex
import cplex

TOLERANCE =10e-6 

class InstanciaRecorridoMixto:
    def __init__(self):
        self.cant_clientes = 0
        self.costo_repartidor = 0
        self.d_max = 0
        self.refrigerados = []
        self.exclusivos = []
        self.distancias = []        
        self.costos = []        

    def leer_datos(self,filename):
        # abrimos el archivo de datos
        f = open(filename)

        # leemos la cantidad de clientes
        self.cant_clientes = int(f.readline())
        # leemos el costo por pedido del repartidor
        self.costo_repartidor = int(f.readline())
        # leemos la distamcia maxima del repartidor
        self.d_max = int(f.readline())
        
        # inicializamos distancias y costos con un valor muy grande (por si falta algun par en los datos)
        self.distancias = [[1000000 for _ in range(self.cant_clientes)] for _ in range(self.cant_clientes)]
        self.costos = [[1000000 for _ in range(self.cant_clientes)] for _ in range(self.cant_clientes)]
        
        # leemos la cantidad de refrigerados
        cantidad_refrigerados = int(f.readline())
        # leemos los clientes refrigerados
        for i in range(cantidad_refrigerados):
            self.refrigerados.append(int(f.readline()))
        
        # leemos la cantidad de exclusivos
        cantidad_exclusivos = int(f.readline())
        # leemos los clientes exclusivos
        for i in range(cantidad_exclusivos):
            self.exclusivos.append(int(f.readline()))
        
        # leemos las distancias y costos entre clientes
        lineas = f.readlines()
        for linea in lineas:
            row = list(map(int,linea.split(' ')))
            self.distancias[row[0]-1][row[1]-1] = row[2]
            self.distancias[row[1]-1][row[0]-1] = row[2]
            self.costos[row[0]-1][row[1]-1] = row[3]
            self.costos[row[1]-1][row[0]-1] = row[3]
        
        # cerramos el archivo
        f.close()

def cargar_instancia():
    # El 1er parametro es el nombre del archivo de entrada
    nombre_archivo = sys.argv[1].strip()
    # Crea la instancia vacia
    instancia = InstanciaRecorridoMixto()
    # Llena la instancia con los datos del archivo de entrada 
    instancia.leer_datos(nombre_archivo)
    return instancia

def agregar_variables(prob, instancia):
    # Definir y agregar las variables:
	# metodo 'add' de 'variables', con parametros:
	# obj: costos de la funcion objetivo
	# lb: cotas inferiores
    # ub: cotas superiores
    # types: tipo de las variables
    # names: nombre (como van a aparecer en el archivo .lp)
	 
    # Poner nombre a las variables y llenar coef_funcion_objetivo
    #Cantidad de clientes
    n= instancia.cant_clientes
    nombres =[]
    coeficientes_funcion_objetivo=[]
    cotas_inferiores=[]
    cotas_superiores=[]
    tipos=[]
    #Primero agrego las de si va o no por un arco x_ij
    for i in range(1,n+1):
        for j in range(1,n+1):
            if(i!=j):
                coeficientes_funcion_objetivo.append(instancia.costos[i-1][j-1])
                nombres.append(f"x_{i}_{j}")
                cotas_inferiores.append(0)
                cotas_superiores.append(1)
                tipos.append('B')
            # else: #i==j
            #     #asignamos un costo muy alto
            #     coeficientes_funcion_objetivo.append(10**6)  #costos alto, el mismo que en la matriz de cosots
            #     nombres.append(f"x_{i}_{i}")
            #     cotas_inferiores.append(0)
            #     cotas_superiores.append(0)  #impedimos que se tomen
            #     tipos.append('B')
    
    #u_1 es 0
    coeficientes_funcion_objetivo.append(0)
    nombres.append("u_1")
    cotas_inferiores.append(0)
    cotas_superiores.append(0) #esto me fija su valor en 0
    tipos.append('I')

    #ahora agrego las de posicion u_i

    for i in range(2,n+1):
        coeficientes_funcion_objetivo.append(0)
        nombres.append(f"u_{i}")
        cotas_inferiores.append(1)
        cotas_superiores.append(n-1)
        tipos.append('I')

    # Agregar las variables
    prob.variables.add(obj = coeficientes_funcion_objetivo, lb = cotas_inferiores, ub = cotas_superiores, types=tipos, names=nombres)

def agregar_restricciones(prob, instancia):
    # Agregar las restricciones ax <= (>= ==) b:
	# funcion 'add' de 'linear_constraints' con parametros:
	# lin_expr: lista de listas de [ind,val] de a
    # sense: lista de 'L', 'G' o 'E'
    # rhs: lista de los b
    # names: nombre (como van a aparecer en el archivo .lp)

    # Notar que cplex espera "una matriz de restricciones", es decir, una
    # lista de restricciones del tipo ax <= b, [ax <= b]. Por lo tanto, aun cuando
    # agreguemos una unica restriccion, tenemos que hacerlo como una lista de un unico
    # elemento.
    n=instancia.cant_clientes

    #salgo de todo cliente
    for i in range(1,n+1):
        variables_salientes = [f"x_{i}_{j}" for j in range(1,n+1) if i!=j]
        valores=[1.0] * (n-1) #que valor toman en la suma(1)
        fila = [variables_salientes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["E"], rhs=[1], names=[f"salgo_de_{i}"])
    
    #entro a todo cliente
    for i in range(1,n+1):
        variables_entrantes = [f"x_{j}_{i}" for j in range(1,n+1) if i!=j]
        valores=[1.0] * (n-1) #que valor toman en la suma(1)
        fila = [variables_entrantes,valores]
        prob.linear_constraints.add(lin_expr=[fila], senses=["E"], rhs=[1], names=[f"llego_a_{i}"])
    
    #continuidad, se vuelta, no considero que sean distintos. la continuidad se cumple si son iguales
    #pues x_ii va a ser 0 siempre
    for i in range(2,n+1):
        for j in range(2,n+1):
            if(j!=i):
                variables=[f"u_{i}",f"u_{j}",f"x_{i}_{j}"]
                valores=[1.0,-1.0,n-1]
                fila=[variables,valores]
                prob.linear_constraints.add(lin_expr=[fila], senses=["L"], rhs=[n-2], names=[f"continuidad_{i}_{j}"])
    


def armar_lp(prob, instancia):

    # Agregar las variables
    agregar_variables(prob, instancia)
   
    # Agregar las restricciones 
    agregar_restricciones(prob, instancia)

    # Setear el sentido del problema
    prob.objective.set_sense(prob.objective.sense.minimize)

    # Escribir el lp a archivo
    prob.write('recorridoMixto.lp')

def resolver_lp(prob):

    # Resolver el lp
    prob.solve()

def mostrar_solucion(prob,instancia):
    
    # Obtener informacion de la solucion a traves de 'solution'
    
    # Tomar el estado de la resolucion
    status = prob.solution.get_status_string(status_code = prob.solution.get_status())
    
    # Tomar el valor del funcional
    valor_obj = prob.solution.get_objective_value()
    
    print('Funcion objetivo: ',valor_obj,'(' + str(status) + ')')
    
    # Tomar los valores de las variables
    x  = prob.solution.get_values()
    nombres_variables  = prob.variables.get_names()#AGREGADO
    # Mostrar las variables con valor positivo (mayor que una tolerancia)
    for i in range(len(x)):#AGREGADO
        if x[i] > TOLERANCE:
            print(nombres_variables[i] + ':' , x[i])

def main():
    
    # Lectura de datos desde el archivo de entrada
    instancia = cargar_instancia()
    def imprimir_costos(instancia):
        for i in range(instancia.cant_clientes):
            for j in range(instancia.cant_clientes):
                print(f"Distancia de {i+1} a {j+1}: {instancia.distancias[i][j]}, Costo: {instancia.costos[i][j]}")

    # Llamar a esta función en tu código principal antes de resolver el problema
    imprimir_costos(instancia)
    
    # Definicion del problema de Cplex
    prob = cplex.Cplex()
    
    # Definicion del modelo
    armar_lp(prob,instancia)
    
    # Resolucion del modelo
    resolver_lp(prob)

    # Obtencion de la solucion
    mostrar_solucion(prob,instancia)

if __name__ == '__main__':
    main()